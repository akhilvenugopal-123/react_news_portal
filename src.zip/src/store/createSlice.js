import { createSlice } from "@reduxjs/toolkit";

const loadNewsFromLocalStorage = () => {
    try {
        const serializedNews = localStorage.getItem("news");
        if (serializedNews === null) {
            return [];
        }
        return JSON.parse(serializedNews);
    } catch (error) {
        return [];
    }
};

export const newsSlice = createSlice({
    name: 'news',
    initialState: {items: loadNewsFromLocalStorage() },
    reducers: {
        addNewsItem: (state, action) => {
            state.items.push(action.payload);
            localStorage.setItem("news", JSON.stringify(state.items));
        },
        
        deleteNewsItem: (state, action) => {
            state.items = state.items.filter(item => item.id !== action.payload);
            localStorage.setItem("news", JSON.stringify(state.items));
        },
        
    },
});

export const { addNewsItem, deleteNewsItem } = newsSlice.actions;
export default newsSlice.reducer;
