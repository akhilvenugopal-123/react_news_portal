import React from "react";
import { useSelector,useDispatch } from "react-redux";
// import { Link } from "react-router-dom";
import { deleteNewsItem  } from "../store/createSlice";
import Navbar from "./Navbar";

function Home(){
    const news = useSelector((state) => state.news.items);
    const dispatch = useDispatch();
    
    
    const handleDeleteNewsItem = (itemId) => {
        dispatch(deleteNewsItem(itemId));
    };
   
    return(

        

        <div className="container">
            <Navbar></Navbar>
            <div className="row ">
                <div className="col-12">
                    <p></p><br></br>
                </div>
            </div>
            
            
            
            {news.map((x) => (
                <div className="row" key={x.id}>
                    <div className="card">
                        <div className="card-title">
                            <h2 style={{float:'left'}} >{x.title}</h2>
                            <button className="btn bg-info" style={{float:'right'}} onClick={() => handleDeleteNewsItem(x.id)}>Delete</button>
                        </div>
                        <div className="card-body">
                            <p>{x.detail}</p>
                        </div>
                    </div><br></br>
                </div>
            ))}
        </div>
    )
}

export default Home;
                    