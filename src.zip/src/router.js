import { createBrowserRouter } from "react-router-dom";
import App from "./App";
import AddNews from "./components/AddNews";


const router = createBrowserRouter([
    {path:'/' , element:<App/>},
    {path:'/Add', element:<AddNews/>}
])


export default router;